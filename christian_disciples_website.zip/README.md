# ✝️ Christian Disciples Church Website

Welcome to the official website project for **Christian Disciples Church**. This is a simple and clean static website built using **HTML**, **CSS**, and **JavaScript** to share the church’s mission, sermons, events, and contact details with the community and the world.

---

## 🌐 Live Website

👉 [Visit Website](https://yourusername.github.io/christian-disciples-church)  
(*Replace with your actual GitHub Pages link after deployment*)

---

## 📁 Project Structure

```
church-website/
├── index.html       # Homepage with sections for about, sermons, events, contact
├── style.css        # Styling for the website
├── script.js        # JavaScript for dynamic content (sermon list)
└── README.md        # Project description and instructions
```

---

## 🚀 How to Run the Project Locally

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/christian-disciples-church.git
   cd christian-disciples-church
   ```

2. **Open `index.html` in a browser**
   - You can double-click it
   - Or use **Live Server** in VS Code for real-time updates

---

## 🛠️ Technologies Used

- HTML5
- CSS3
- JavaScript (Vanilla)
- [GitHub Pages](https://pages.github.com/) for deployment

---

## ✍️ Future Improvements (Optional Ideas)

- Add a gallery page
- Add a contact form with email functionality
- Add sermon video/audio support
- Make the design fully responsive for mobile devices

---

## 🤝 Contributing

Contributions, suggestions, and prayers are welcome!  
To contribute:
- Fork this repo
- Make changes
- Open a pull request

---

## 🙏 Credits

This project was developed with the goal of spreading the Gospel through digital platforms. Glory to God!

---

## 📞 Contact

- Email: contact@christiandisciples.org
- Facebook: @ChristianDisciplesChurch
