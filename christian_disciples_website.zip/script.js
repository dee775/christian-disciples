// Example dynamic sermon listing
const sermons = [
  "Walking by Faith - June 23, 2025",
  "Love and Forgiveness - June 16, 2025",
  "Overcoming Trials - June 9, 2025"
];

const sermonList = document.getElementById("sermon-list");

sermons.forEach((sermon) => {
  const li = document.createElement("li");
  li.textContent = sermon;
  sermonList.appendChild(li);
});
